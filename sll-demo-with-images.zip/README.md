Smart Leftover Logistics — Demo with Images

Open public/index.html in a browser to view the demo. The site uses SVG images located in public/assets and stores demo data in localStorage under key 'sll_demo'.

// Wire up reservation buttons on index page and sync demo storage
function read(){ try{ return JSON.parse(localStorage.getItem('sll_demo')||'[]') }catch(e){ return [] } }
function save(v){ localStorage.setItem('sll_demo', JSON.stringify(v)) }
function ensureSeed(){
  const cur = read()
  if(cur.length) return
  const sample = [
    { id:'s1', title:'Day-old Bread', quantity:10, unit:'pcs', status:'AVAILABLE' },
    { id:'s2', title:'Mixed Pastries', quantity:18, unit:'pcs', status:'AVAILABLE' },
    { id:'s3', title:'Cooked Rice (boxed)', quantity:6, unit:'boxes', status:'AVAILABLE' }
  ]
  save(sample)
}
window.addEventListener('load', ()=>{
  ensureSeed()
  document.querySelectorAll('.reserve').forEach(b=>{
    b.addEventListener('click', (e)=>{
      const id = e.currentTarget.getAttribute('data-id')
      const items = read()
      const idx = items.findIndex(x=>x.id===id)
      if(idx>-1){
        items[idx].status = 'RESERVED'
        save(items)
        alert('Reserved locally (demo). Go to Delivery to update status.')
        location.reload()
      }
    })
  })
})
